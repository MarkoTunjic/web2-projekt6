<template>
  <div class="about">
    <h1>This is a project build for the class "Napredni razvoj programske potpore za web" aka. WEB2 at the FER
      University Croatia</h1>
  </div>
</template>

<style>
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>
